

def sumar(op1, op2):
	print("El resultado de la suma es: ", op1+op2)

def restar(op1,op2):
	a = int(input("Como deseas ejecutar la resta presiona 1- (x-y) o 2-(y-x)"))
	if a == 1:
		print("El resultado de la resta es: ", op1-op2)
	elif a == 2:
		print("El resultado de la resta es: ", op2-op1)
	else:
		print("La opcion elegida no esta contemplada")

def multiplicar(op1, op2):
	print("El resultado de la multiplicacion es: ", op1*op2)

def division(op1,op2):
	a = int(input("Como deseas ejecutar la division presiona 1- (x/y) o 2- (y/x)"))
	if a == 1:
		print("El resultado de la resta es: ", op1/op2)
	elif a == 2:
		print("El resultado de la resta es: ", op2/op1)
	else:
		print("La opcion elegida no esta contemplada")

def potencia(base, exponente):
	print("El resultado de la potencia es: ", base**exponente)

def redondear(numero):
	print("El resultado del redondeo es: ", round(numero))