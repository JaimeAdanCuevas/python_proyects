from setuptools import setup

setup(

	name="paquetecalculos", 
	version="1.0",
	description="Paquete de redondeo de potencia",
	author="Adan",
	author_email="adancuevas@outlook.com",
	url="www.facebook.com",
	packages=["calculos"]

	)